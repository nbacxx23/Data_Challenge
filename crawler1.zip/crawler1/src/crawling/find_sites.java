package crawling;

import java.awt.List;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class find_sites{
	public static Set<String> extract(String nextlink,File file) throws IOException{
		Set<String> LinkSet = new HashSet<String>();
		String oldLinkHost = nextlink;
		BufferedReader reader= new BufferedReader(new FileReader(file));
		String line = new String();
		Pattern pattern = Pattern.compile("<a.*?href=[\"']?((https?://)?/?[^\"']+)[\"']?.*?>(.+)</a>");
		Matcher matcher = null;
		while ((line = reader.readLine()) != null){
			matcher = pattern.matcher(line);
			if (matcher.find()) {
				String newLink = matcher.group(1).trim();
				if (newLink.contains(" ")){
					newLink = newLink.split(" ")[0];
				}
				if (!newLink.startsWith("http")) {
					if (newLink.startsWith("/"))
						newLink = oldLinkHost + newLink;
					else
						newLink = oldLinkHost + "/" + newLink;
				}
				
				if(newLink.endsWith("/"))
					newLink = newLink.substring(0, newLink.length() - 1);
				LinkSet.add(newLink);
				
			}
	}
		return LinkSet;
	}
	
}
	