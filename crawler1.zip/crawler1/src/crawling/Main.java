package crawling;
import java.io.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;
public class Main{
	public static void main(String[] args) throws IOException{
		Queue<String> queue=new LinkedList<String>();
		Set<String> finished_links = new HashSet<String>();
		String url = "http://nba.sports.sina.com.cn/match_result.php";
		queue.add(url);
		FileWriter fw = new FileWriter (new File("/home/yuxiang/Documents/record.txt"));
		BufferedWriter bw = new BufferedWriter (fw);
		PrintWriter record = new PrintWriter (bw);	
		int k = 0;
		while (!queue.isEmpty()&&k<300)
		{	
			Set<String> Set_links = new HashSet<String>();
			String result = new String();
			String nextlink = queue.poll();
			while(finished_links.contains(nextlink))
				{
					nextlink = queue.poll();
				}
			result = read_site.read(nextlink);
			System.out.println(k);
			read_site.write_txt(k, result);
			File file = new File("/home/yuxiang/Documents/page/"+k+".txt");
			Set_links = find_sites.extract(nextlink,file);
			queue.addAll(Set_links);
			k = k+1;
			finished_links.add(nextlink);
			System.out.println(queue.size());
		}
		for(String i:finished_links){
			record.println(i + "\n");
		}
		
		record.close();
	}

}